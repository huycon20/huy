package Finally;

public class EducationException extends Exception {
	public EducationException() {
		
	}
	public EducationException(String message) {
		super(message);
	}
}
