package Finally;

import java.io.FileNotFoundException;

public class Developer extends Employee{
	@Override
	public void work() throws FileNotFoundException{
		
	}
	@Override
	public void work(String location) throws ArithmeticException{
		
	}
}	
